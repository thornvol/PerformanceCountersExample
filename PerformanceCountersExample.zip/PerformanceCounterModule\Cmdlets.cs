﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management.Automation;
using PerformanceCounterHelper;

namespace PerformanceCounterModule
{
    [Cmdlet(VerbsCommon.Get, "PerformanceMetrics")]
    public class GetPerformanceMetrics : Cmdlet
    {
        [Parameter(Position = 0,
            ValueFromPipelineByPropertyName = true,
            ValueFromPipeline = true,
            HelpMessage = "An array of performance counter names to measure.")]
        public string[] CounterNames { get; set; }

        protected override void BeginProcessing()
        {
            base.BeginProcessing();
        }

        protected override void ProcessRecord()
        {
            base.ProcessRecord();

            // Could use constructor with mutliple parameters using the CounterNames parameter. 
            // Example, var metric = new PerformanceMetrics(CounterNames);
            var metric = new PerformanceMetrics(); 

            // Run Get Metrics
            metric.GetPerformanceMetrics();

            // Write metric to output pipeline 
            // only writing cpu results now, you can create another method to return memory usage 
            // or add a parameter specifying which one you want to return into this method

            // Only show 2 columns we are interested in (you could do this in the PerformanceMetrics class)
            var results =
                metric.CpuPercentUsage.Select(m => new {ProcessName = m.ProcessName, CpuPercent = m.CounterValue});

            WriteObject(results);
        }

        protected override void EndProcessing()
        {
            base.EndProcessing();
        }
    }
}
