﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformanceCountersExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Counter list to track
            var counterInfolist = new[]
            {
                new PerformanceCounterHelper.CounterInfo
                {
                    CategoryName = "Process",
                    CounterName = "Working Set - Private"
                },
                new PerformanceCounterHelper.CounterInfo {CategoryName = "Process", CounterName = "% Processor Time"}
            };

            var processors = Environment.ProcessorCount;

            // Get Process Ids for all running processes
            var processesIds = System.Diagnostics.Process.GetProcesses().Select(p => p.Id);
            //processesIds.Dump();

            // Get individual instance names for each Process Id
            // Assumes single category for now "Process" - you would need to refactor for multiple categories (i.e., place the below within the counterInfoList foreach loop)
            var names = processesIds.Select(i => PerformanceCounterHelper.GetInstanceNameForProcessId(i, "Process")).ToList();
            //names.Dump();

            var performanceCounters = new List<PerformanceCounter>();

            // Get Performance Counters for each process name
            foreach (var counterInfo in counterInfolist)
            {
                // Create performance counter for each process name in the counterinfo list
                var counters = names.Select(n => new PerformanceCounter(counterInfo.CategoryName, counterInfo.CounterName, n)).ToList();

                // Call NextValue for each counter
                counters.ForEach(c => c.NextValue());

                // Add to overall counter collection
                performanceCounters.AddRange(counters);
            }

            // List of Memory counter per process
            var memory = performanceCounters
                            .Where(counter => counter.CounterName == "Working Set - Private")
                            .Select(counter => PerformanceCounterHelper.GetProcessInformation(counter.InstanceName, counter.CounterName, PerformanceCounterHelper.CalculateCounterValue(counter, processors)))
                            .OrderByDescending(counter => counter.CounterValue);

            // List of CPU% usage per process
            var cpu = performanceCounters
                            .Where(counter => counter.CounterName == "% Processor Time")
                            .Select(counter => PerformanceCounterHelper.GetProcessInformation(counter.InstanceName, counter.CounterName, PerformanceCounterHelper.CalculateCounterValue(counter, processors)))
                            .OrderByDescending(counter => counter.CounterValue);

            Console.WriteLine("Memory Usage");
            memory.ToList().ForEach(i => Console.WriteLine($"Process Name: {i.ProcessName} | Usage (KB): {i.CounterValue}"));

            Console.WriteLine("CPU % Usage");
            cpu.ToList().ForEach(i => Console.WriteLine($"Process Name: {i.ProcessName} | Cpu Usage (%): {i.CounterValue}"));

            // Hit enter to exit window
            Console.ReadKey();
        }
    }

    public class PerformanceCounterHelper
    {
        public static string GetInstanceNameForProcessId(int processId, string categoryName)
        {
            var process = Process.GetProcessById(processId);
            var processName = Path.GetFileNameWithoutExtension(process.ProcessName);

            var cat = new PerformanceCounterCategory(categoryName);
            var instances = cat.GetInstanceNames()
                .Where(inst => inst.StartsWith(processName))
                .ToArray();

            foreach (var instance in instances)
            {
                using (var cnt = new PerformanceCounter(categoryName, "ID Process", instance, true))
                {
                    var val = (int)cnt.RawValue;
                    if (val == processId)
                    {
                        return instance;
                    }
                }
            }
            return null;
        }

        public static double CalculateCounterValue(PerformanceCounter counter, int processors)
        {
            var rtnValue = 0d; //0d is short for 0 as double

            switch (counter.CounterName)
            {
                case "Working Set - Private":
                    rtnValue = Math.Round((counter.NextValue() / 1024)); //KB
                    break;
                case "% Processor Time":
                    rtnValue = Math.Round((counter.NextValue() / processors));
                    break;
                default:
                    rtnValue = 0;
                    break;
            }

            return rtnValue;
        }

        public static ProcessInformation GetProcessInformation(string processname, string countername, double value)
        {
            return new ProcessInformation
            {
                ProcessName = processname,
                CounterName = countername,
                CounterValue = value
            };
        }

        public class CounterInfo
        {
            public string CategoryName { get; set; }
            public string CounterName { get; set; }
        }

        public class ProcessInformation
        {
            public string ProcessName { get; set; }
            public string CounterName { get; set; }
            public double CounterValue { get; set; }
        }
    }
}
